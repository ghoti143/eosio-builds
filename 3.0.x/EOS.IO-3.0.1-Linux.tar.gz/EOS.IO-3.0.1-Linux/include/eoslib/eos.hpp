/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
#pragma once
#include <eoslib/types.hpp>
#include <eoslib/action.hpp>
#include <eoslib/print.hpp>
#include <eoslib/math.hpp>




